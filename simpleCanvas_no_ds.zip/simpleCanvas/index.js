var width = 171;
var height = 108;

var scale = 3;

var drawConfig = {
    "mastercard": {
        "cardNo": {
            "sx": 53,
            "sy": 185,
            "tx": "",
            "ty": "",
            "font": "23px Farrington7B",
            "color": "rgba(202,202,203,1)",
            "letterSpacing": "4.4px"
        },
        "expireDate": {
            "sx": 242,
            "sy": 240,
            "tx": "",
            "ty": "",
            "font": "12px Farrington7B",
            "color": "rgba(202,202,202,1)",
            "letterSpacing": "4px"
        },
        "holderName": {
            "sx": 52,
            "sy": 280,
            "tx": "",
            "ty": "",
            "font": "20px AvenirNextCondensedMedium",
            "color": "rgba(202,202,203,1)",
            "letterSpacing": "3.5px"
        },
        "cvv": {
            "sx": 312,
            "sy": 153,
            "tx": "",
            "ty": "",
            "font": "25px PPPangramSansRoundedSlimMediumReclined",
            "color": "rgba(0,0,0,1)",
            "letterSpacing": "0.2px"
        }
    },
    "visa": {
        "cardNo": {
            "sx": 50,
            "sy": 185,
            "tx": "",
            "ty": "",
            "font": "25px Farrington7B",
            "color": "rgba(255, 237, 85, 1)",
            "letterSpacing": "4.4px"
        },
        "expireDate": {
            "sx": 265,
            "sy": 250,
            "tx": "",
            "ty": "",
            "font": "17px FontsFreeNetArialBold",
            "color": "rgba(255, 237, 85, 1)",
            "letterSpacing": "3px"
        },
        "holderName": {
            "sx": 52,
            "sy": 280,
            "tx": "",
            "ty": "",
            "font": "20px AvenirNextCondensedMedium",
            "color": "rgba(255, 237, 85, 1)",
            "letterSpacing": "2px"
        },
        "cvv": {
            "sx": 324,
            "sy": 153,
            "tx": "",
            "ty": "",
            "font": "25px PPPangramSansRoundedSlimMediumReclined",
            "color": "rgba(0,0,0,1)",
            "letterSpacing": "0.2px"
        }
    }
}


function cardOrganizationSelectChanged() {
    //加载卡面底片
    loadImage(cardOrganization());
}


function drawInfomation() {
    clearCanvas()
    if (cardOrganization() == 'Visa') {
        draw(drawConfig.visa);
    } else {
        draw(drawConfig.mastercard);
    }
}

function draw(config) {
    //先画卡
    getFrontCanvas().drawImage(frontImage, 0, 0, width * scale, height * scale);
    getBackCanvas().drawImage(backImage, 0, 0, width * scale, height * scale);
    console.log("画卡面完成")
    var frontCanvas = getFrontCanvas();
    var backCanvas = getBackCanvas();
    //先画卡号
    var cardNo = getCardNo();
    frontCanvas.letterSpacing = config.cardNo.letterSpacing;
    frontCanvas.font = config.cardNo.font;
    frontCanvas.fillStyle = config.cardNo.color;
    frontCanvas.shadowColor = 'rgba(0, 0, 0, 0.3)';
    // 将阴影向右移动15px，向上移动10px
    frontCanvas.shadowOffsetX = 1;
    frontCanvas.shadowOffsetY = 1;
    // 轻微模糊阴影
    // frontCanvas.shadowBlur = 0.2;
    frontCanvas.fillText(cardNo, config.cardNo.sx, config.cardNo.sy);
    console.log("卡号完成")
    //有效期
    var expireDate = getExpireDate();
    frontCanvas.letterSpacing = config.expireDate.letterSpacing;
    frontCanvas.font = config.expireDate.font;
    frontCanvas.fillStyle = config.cardNo.color;
    frontCanvas.fillText(expireDate, config.expireDate.sx, config.expireDate.sy);
    console.log("有效期完成")
    //持卡人
    var holderName = getCardHolderName();
    frontCanvas.letterSpacing = config.holderName.letterSpacing;
    frontCanvas.font = config.holderName.font;
    frontCanvas.fillStyle = config.cardNo.color;
    frontCanvas.fillText(holderName, config.holderName.sx, config.holderName.sy);
    console.log("持卡人完成")
    //背面的cvv
    var cvv = getCvv();
    backCanvas.letterSpacing = config.cvv.letterSpacing;
    backCanvas.font = config.cvv.font;
    backCanvas.fillStyle = config.cvv.color;
    backCanvas.fillText(cvv, config.cvv.sx, config.cvv.sy);
}

//https://developer.mozilla.org/zh-CN/docs/Web/API/Canvas_API/Tutorial/Drawing_text
// function drawMastercard() {
//     var mastercardConfig = drawConfig.mastercard;
//     //先画卡
//     getFrontCanvas().drawImage(frontImage, 0, 0, width * scale, height * scale);
//     getBackCanvas().drawImage(backImage, 0, 0, width * scale, height * scale);
//     console.log("画卡面完成")
//     var frontCanvas = getFrontCanvas();
//     var backCanvas = getBackCanvas();
//     //先画卡号
//     var cardNo = getCardNo();
//     frontCanvas.letterSpacing = mastercardConfig.cardNo.letterSpacing;
//     frontCanvas.font = mastercardConfig.cardNo.font;
//     frontCanvas.strokeText(cardNo, mastercardConfig.cardNo.sx, mastercardConfig.cardNo.sy);
//     console.log("卡号完成")
//     //有效期
//     var expireDate = getExpireDate();
//     frontCanvas.letterSpacing = mastercardConfig.expireDate.letterSpacing;
//     frontCanvas.font = mastercardConfig.expireDate.font;
//     frontCanvas.strokeText(expireDate, mastercardConfig.expireDate.sx, mastercardConfig.expireDate.sy);
//     console.log("有效期完成")
//     //持卡人
//     var holderName = getCardHolderName();
//     frontCanvas.letterSpacing = mastercardConfig.holderName.letterSpacing;
//     frontCanvas.font = mastercardConfig.holderName.font;
//     frontCanvas.strokeText(holderName, mastercardConfig.holderName.sx, mastercardConfig.holderName.sy);
//     console.log("持卡人完成")
//     //背面的cvv
//     var cvv = getCvv();
//     backCanvas.letterSpacing = mastercardConfig.cvv.letterSpacing;
//     backCanvas.font = mastercardConfig.cvv.font;
//     backCanvas.strokeText(cvv, mastercardConfig.cvv.sx, mastercardConfig.cvv.sy);
// }
//
// function drawVisa() {
//     getFrontCanvas().drawImage(frontImage, 0, 0, width * scale, height * scale);
//     getBackCanvas().drawImage(backImage, 0, 0, width * scale, height * scale);
//     //先画卡号
//     var cardNo = getCardNo();
//     //https://developer.mozilla.org/zh-CN/docs/Web/API/Canvas_API/Tutorial/Drawing_text
//     var frontCanvas = getFrontCanvas();
//     frontCanvas.font = drawConfig.visa.cardNo.font;
//     frontCanvas.strokeText(cardNo, drawConfig.visa.cardNo.sx, drawConfig.visa.cardNo.sy);
// }

function clearCanvas() {
    console.log("清除原有元素")
    getFrontCanvas().clearRect(0, 0, width * scale, height * scale);
    getBackCanvas().clearRect(0, 0, width * scale, height * scale);
}


window.onload = function () {
    //页面加载完成
    //加载卡面信息
    loadImage(cardOrganization());
    //设置下载按钮
    setDownloadAction();
    //输入框变动
    setInputChanged();
}

function getExpireDate() {
    var expireDate = document.getElementById("expireDate").value;
    return expireDate;
}

function getCardHolderName() {
    var holderName = document.getElementById("holderName").value;
    holderName = holderName.toUpperCase();
    return holderName;
}

function getCvv() {
    var cvv = document.getElementById("cvv").value;
    return cvv;
}

function getSimpleCardNo() {
    var cardNo = document.getElementById("cardNo").value;
    return cardNo;
}

function getCardNo() {
    var cardNo = document.getElementById("cardNo").value;
    var resultCardNo = "";
    resultCardNo += cardNo.substring(0, 4);
    resultCardNo += "  ";
    resultCardNo += cardNo.substring(4, 8);
    resultCardNo += "  ";
    resultCardNo += cardNo.substring(8, 12);
    resultCardNo += "  ";
    resultCardNo += cardNo.substring(12, 16);
    return resultCardNo;
}

function setInputChanged() {
    document.getElementById("cardNo").oninput = function () {
        drawInfomation();
    };
    document.getElementById("expireDate").oninput = function () {
        drawInfomation();
    };
    document.getElementById("holderName").oninput = function () {
        drawInfomation();
    };
    document.getElementById("cvv").oninput = function () {
        drawInfomation();
    };
}

function setDownloadAction() {
    document.getElementById("download").onclick = function () {
        downloadImage("front", getSimpleCardNo() + "_正面");
        downloadImage("back", getSimpleCardNo() + "_反面");
    };
    // document.getElementById("drawCard").onclick = function () {
    //     drawInfomation();
    // };
}

var frontImage = new Image();
var backImage = new Image();

function loadImage(cardOrganization) {
    if (cardOrganization == 'Visa') {
        //visa
        frontImage.src = visaFrontBase64;
        backImage.src = visaBackBase64;
    } else {
        //mastercard
        frontImage.src = mastercardFrontBase64;
        backImage.src = mastercardBackBase64;
    }

    frontImage.onload = function () {
        drawInfomation();
    };
    backImage.onload = function () {
        drawInfomation();
    }
}


function getFrontCanvas() {
    return document.getElementById("front").getContext('2d');
}

function getBackCanvas() {
    return document.getElementById("back").getContext('2d');
}

function downloadImage(elementId, fileName) {
    let a = document.createElement('a');
    a.download = fileName + ".png";
    a.href = document.getElementById(elementId).toDataURL("image/png");
    a.click();
}

function cardOrganization() {
    var selects = document.getElementById("cardOrganizationSelect");
    var index = selects.selectedIndex;
    return selects.options[index].value;
}